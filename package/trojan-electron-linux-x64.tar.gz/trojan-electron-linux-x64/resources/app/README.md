# trojan-electron

trojan dashboard electron version
